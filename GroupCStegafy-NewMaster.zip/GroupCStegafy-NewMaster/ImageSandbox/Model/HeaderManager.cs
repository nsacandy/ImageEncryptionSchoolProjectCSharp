﻿using Windows.UI;
using GroupCStegafy.Utils;

namespace GroupCStegafy.Model
{
    /// <summary>
    ///     Defines the HeaderManager model class.
    /// </summary>
    public class HeaderManager
    {
        #region Data members

        private readonly Picture sourcePicture;

        #endregion

        #region Properties

        /// <summary>
        ///     Gets a value indicating whether this instance is encrypted.
        /// </summary>
        /// <value>
        ///     <c>true</c> if this instance is encrypted; otherwise, <c>false</c>.
        /// </value>
        public bool IsEncrypted { get; private set; }

        /// <summary>
        ///     Gets the bpcc.
        /// </summary>
        /// <value>
        ///     The bpcc.
        /// </value>
        public int Bpcc { get; private set; }

        /// <summary>
        ///     Gets a value indicating whether this instance is text.
        /// </summary>
        /// <value>
        ///     <c>true</c> if this instance is text; otherwise, <c>false</c>.
        /// </value>
        public bool IsText { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="HeaderManager" /> class.
        /// </summary>
        /// <param name="sourcePicture">The source picture.</param>
        public HeaderManager(Picture sourcePicture)
        {
            this.sourcePicture = sourcePicture;
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Updates the header information.
        /// </summary>
        /// <param name="isEncrypted">if set to <c>true</c> [is encrypted].</param>
        /// <param name="isText">if set to <c>true</c> [is text].</param>
        /// <param name="bpcc">The bpcc.</param>
        public void UpdateHeaderInfo(bool isEncrypted, bool isText, int bpcc)
        {
            this.IsEncrypted = isEncrypted;
            this.IsText = isText;
            this.Bpcc = bpcc;
        }

        /// <summary>
        ///     Sets the header for hidden message.
        /// </summary>
        /// <returns>
        ///     source pixels
        /// </returns>
        public byte[] SetHeaderForHiddenMessage()
        {
            var imageWithHeader = this.sourcePicture.Pixels;
            for (var i = 0; i < 2; i++)
            {
                var pixelColor = PixelManager.GetPixelBgra8(imageWithHeader, Constants.Constants.FirstX, i,
                    this.sourcePicture.Width,
                    this.sourcePicture.Height);
                if (i == Constants.Constants.FirstX)
                {
                    this.setFirstPixel(pixelColor, imageWithHeader);
                }
                else
                {
                    this.setSecondPixel(pixelColor, imageWithHeader);
                }
            }

            return imageWithHeader;
        }

        /// <summary>
        ///     Skips the header location.
        /// </summary>
        /// <param name="height">The height.</param>
        /// <param name="width">The width.</param>
        /// <returns>
        ///     Width
        /// </returns>
        public static int SkipHeaderLocation(int height, int width)
        {
            switch (height)
            {
                case 0 when width == 0:
                    width += 2;
                    break;
                case 0 when width == 1:
                    width++;
                    break;
            }

            return width;
        }

        /// <summary>
        ///     Checks for encryption.
        /// </summary>
        /// <param name="pixelColor">Color of the pixel.</param>
        /// <returns>
        ///     True if LSB == 0, False otherwise
        /// </returns>
        public static bool CheckForEncryption(Color pixelColor)
        {
            return PixelManager.GetLeastSignificantBit(pixelColor.R) != 0;
        }

        /// <summary>
        ///     Checks the BPCC value.
        /// </summary>
        /// <param name="pixelColor">Color of the pixel.</param>
        /// <returns>
        ///     Bpcc value
        /// </returns>
        public static int CheckBpccValue(Color pixelColor)
        {
            return pixelColor.G;
        }

        /// <summary>
        ///     Determines whether [contains hidden message].
        /// </summary>
        /// <param name="pixelColor">Color of the pixel.</param>
        /// <returns>
        ///     <c>true</c> if [contains hidden message]; otherwise, <c>false</c>.
        /// </returns>
        public static bool ContainsHiddenMessage(Color pixelColor)
        {
            return pixelColor.R == 212 && pixelColor.G == 212 && pixelColor.B == 212;
        }

        /// <summary>
        ///     Determines whether this instance is text.
        /// </summary>
        /// <param name="pixelColor">Color of the pixel.</param>
        /// <returns>
        ///     <c>true</c> if this instance is text; otherwise, <c>false</c>.
        /// </returns>
        public static bool CheckFileType(Color pixelColor)
        {
            return PixelManager.GetLeastSignificantBit(pixelColor.B) != 0;
        }

        private void setFirstPixel(Color pixelColor, byte[] imageWithHeader)
        {
            pixelColor.R = 212;
            pixelColor.G = 212;
            pixelColor.B = 212;
            PixelManager.SetPixelBgra8(imageWithHeader, Constants.Constants.FirstX, Constants.Constants.FirstX,
                pixelColor, this.sourcePicture.Width,
                this.sourcePicture.Height);
        }

        private void setSecondPixel(Color pixelColor, byte[] imageWithHeader)
        {
            if (this.IsEncrypted)
            {
                pixelColor.R |= 1;
            }
            else
            {
                pixelColor.R &= 0xfe;
            }

            if (this.IsText)
            {
                pixelColor.B |= 1;
            }
            else
            {
                pixelColor.B &= 0xfe;
            }

            pixelColor.G = (byte) this.Bpcc;
            PixelManager.SetPixelBgra8(imageWithHeader, Constants.Constants.FirstX, Constants.Constants.SecondX,
                pixelColor, this.sourcePicture.Width,
                this.sourcePicture.Height);
        }

        #endregion
    }
}