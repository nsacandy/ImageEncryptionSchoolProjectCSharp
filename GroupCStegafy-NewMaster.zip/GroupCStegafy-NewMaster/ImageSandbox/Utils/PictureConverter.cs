﻿using System;
using System.Collections.Generic;
using System.Text;
using GroupCStegafy.Model;

namespace GroupCStegafy.Utils
{
    /// <summary>
    ///     Defines the PictureConverter class.
    /// </summary>
    public static class PictureConverter
    {
        #region Methods

        /// <summary>
        ///     Converts the bytes into binary string.
        /// </summary>
        /// <param name="picture">The picture.</param>
        /// <returns>
        ///     StringBuilder
        /// </returns>
        public static StringBuilder ConvertBytesIntoBinaryString(Picture picture)
        {
            var byteArray = PictureToByteArray(picture);
            var stringBuilder = new StringBuilder();

            foreach (var currentByte in byteArray)
            {
                stringBuilder.Append(Convert.ToString(currentByte, 2).PadLeft(8, '0'));
            }

            return stringBuilder;
        }

        /// <summary>
        ///     Picture to byte array.
        /// </summary>
        /// <param name="picture">The picture.</param>
        /// <returns>
        ///     Byte array
        /// </returns>
        public static byte[] PictureToByteArray(Picture picture)
        {
            var amountOfPixels = picture.Width * picture.Height * 3;
            var array = new byte[amountOfPixels];
            var arrayIndex = 0;
            for (var i = 0; i < picture.Height; i++)
            {
                for (var j = 0; j < picture.Width; j++)
                {
                    j = HeaderManager.SkipHeaderLocation(i, j);

                    var sourcePixelColor = PixelManager.GetPixelBgra8(picture.Pixels, i, j,
                        picture.Width, picture.Height);

                    var bytes = new List<byte> {
                        sourcePixelColor.R,
                        sourcePixelColor.G,
                        sourcePixelColor.B
                    };

                    foreach (var b in bytes)
                    {
                        array[arrayIndex] = b;
                        arrayIndex++;
                    }
                }
            }

            return array;
        }

        #endregion
    }
}