﻿namespace GroupCStegafy.Enums
{
    /// <summary>Defines the EncryptionType enum class.</summary>
    public enum EncryptionType
    {
        /// <summary>The encrypted</summary>
        Encrypted,

        /// <summary>The non encrypted</summary>
        NonEncrypted
    }
}